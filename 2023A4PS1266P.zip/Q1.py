t=int(input())


for i in range(t):
    strings=input()
    l=strings.split(" ")
    s1=l[0]
    s2=l[1]
    s3=""
    for i in s1:
        if i in s2:
            s3+=i

    if s3==s1:
        print("Yes")
    else:
        print("No")

def multiply_matrices(mat1, mat2):
    n = len(mat1)
    result = [[0] * n for _ in range(n)]

    for i in range(n):
        for j in range(n):
            for k in range(n):
                result[i][j] += mat1[i][k] * mat2[k][j]

    return result
def trace_of_matrix(mat):
    n = len(mat)
    trace = 0
    for i in range(n):
        trace += mat[i][i]
    return trace
n = int(input())
mat1 = []
for i in range(n):
    row = list(map(int, input().split()))
    mat1.append(row)
mat2 = []
for i in range(n):
    row = list(map(int, input().split()))
    mat2.append(row)
resultant_matrix = multiply_matrices(mat1, mat2)
trace=trace_of_matrix(resultant_matrix)
print(trace)
    

def find_shortest_initial_string(final_string):
    l = list(final_string)

    while len(l) > 1:
        left_char = l[0]
        right_char = l[-1]

        
        if left_char == '0' and right_char == '1':
            l.pop()
            l.pop(0)
        elif left_char == '1' and right_char == '0':
            l.pop()
            l.pop(0)
        else:
            break

    
    shortest_length = len(l)

    return shortest_length


T = int(input("Enter the number of test cases: "))


for _ in range(T):
    final_string = input("Enter the final string: ")
    shortest_length = find_shortest_initial_string(final_string)
    print("Shortest initial string length:", shortest_length)
